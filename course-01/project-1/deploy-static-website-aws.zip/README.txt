CloudFront URL: https://ds2ximh23w1i0.cloudfront.net/
Website endpoint URL: http://my-363861964381-bucket.s3-website-us-east-1.amazonaws.com/
S3 Object URL: https://my-363861964381-bucket.s3.us-east-1.amazonaws.com/index.html

